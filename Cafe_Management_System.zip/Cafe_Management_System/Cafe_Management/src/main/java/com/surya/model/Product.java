package com.surya.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.ManyToAny;

import lombok.Data;

@NamedQuery(name = "Product.getAllProducts",query = "select new com.surya.wrapper.ProductWrapper(p.id,p.name,p.description,p.price,p.status,p.category.id,p.category.name) from Product p")
@NamedQuery(name = "Product.updateProductStatus",query = "update Product p set p.status =:status where p.id = :id")
@NamedQuery(name = "Product.getProductByCategory",query = "select new com.surya.wrapper.ProductWrapper(p.id,p.name) from Product p where p.category.id = :id and p.status = 'true'")
@NamedQuery(name = "Product.getProductById",query = "select new com.surya.wrapper.ProductWrapper(p.id,p.name,p.description,p.price,p.status,p.category.id,p.category.name) from Product p where p.id = :id")

@Data
@Entity
@DynamicInsert
@DynamicUpdate
@Table
public class Product implements Serializable{
	
	public static final Long serialVersionUID = 123456L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column
	private Integer id;
	
	@Column
	private String name;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "category_fk",nullable = false)
	private Category category;
	
	@Column
	private String description;
	
	@Column
	private Integer price;
	
	@Column
	private String status;
}
