package com.surya.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;

import com.google.common.base.Strings;
import com.surya.DAO.UserDAO;
import com.surya.JWT.CustomerUserDetailsService;
import com.surya.JWT.JwtFilter;
import com.surya.JWT.JwtUtil;
import com.surya.constants.CafeConstants;
import com.surya.model.User;
import com.surya.utils.CafeUtils;
import com.surya.utils.EmailUtils;
import com.surya.wrapper.UserWrapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@org.springframework.stereotype.Service
public class ServiceImpl implements Service {
	
	@Autowired
	UserDAO userDAO;
	
	@Autowired
	AuthenticationManager authenticationManager;
	
	@Autowired
	CustomerUserDetailsService customerUserDetailsService;
	
	@Autowired
	JwtUtil jwtUtil;
	
	@Autowired
	JwtFilter jwtFilter;
	
	@Autowired
	EmailUtils emailUtils;
	
	@Override
	public ResponseEntity<String> signUp(Map<String, String> requestMap) {
		Logger logger = LoggerFactory.getLogger(ServiceImpl.class);
		logger.info("data : "+requestMap);
		try {
			
			if(validationSignUp(requestMap)) {
				User user = userDAO.findByEmailId(requestMap.get("email"));
				if(Objects.isNull(user)) {
					userDAO.save(getUser(requestMap));
					return CafeUtils.getResponseEntity("Successfully registered", HttpStatus.OK);
				}
				else {
					return CafeUtils.getResponseEntity("Email already exist", HttpStatus.BAD_REQUEST);
				}
			}
			else {
				logger.info("user sent invalid data");
				return CafeUtils.getResponseEntity(CafeConstants.INVALID_DATA, HttpStatus.BAD_REQUEST);
			}
		}catch(Exception e) {
				e.printStackTrace();
			}
		return CafeUtils.getResponseEntity(CafeConstants.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	private boolean validationSignUp(Map<String,String> requestMap) {
		return requestMap.containsKey("name") && requestMap.containsKey("contactNumber") &&
		requestMap.containsKey("email") && requestMap.containsKey("password");
	}
	
	private User getUser(Map<String,String> requestMap) {
		User user = new User();
		user.setName(requestMap.get("name"));
		user.setContactNumber(requestMap.get("contactNumber"));
		user.setEmail(requestMap.get("email"));
		user.setPassword(requestMap.get("password"));
		user.setRole("user");
		user.setStatus("false");
		
		return user;
	}

	@Override
	public ResponseEntity<String> login(Map<String, String> requestMap) {
		log.info("Inside login");
		
		try {
			Authentication auth = authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(requestMap.get("email"), requestMap.get("password")));
			if (auth.isAuthenticated()) {
				if(customerUserDetailsService.getUserDetail().getStatus().equalsIgnoreCase("true")) {
					return new ResponseEntity<String>("{\"token\":\""+
				jwtUtil.generateToken(customerUserDetailsService.getUserDetail().getEmail(), customerUserDetailsService.getUserDetail().getRole())+ "\"}"
						,HttpStatus.OK);
				}
			else {
				return new ResponseEntity<String>("{\"message\":\""+"wait for admin approval."+"\"}"
						,HttpStatus.BAD_REQUEST);
			   }
			}
		}catch(Exception e) {
			log.error("{}",e);
		}
		return new ResponseEntity<String>("{\"message\":\""+"Bad Credentials"+"\"}"
				,HttpStatus.BAD_REQUEST);	
		}

	@Override
	public ResponseEntity<List<UserWrapper>> getAllUsers() {
		try {
			if(jwtFilter.isAdmin()) {
				return new ResponseEntity<List<UserWrapper>>(userDAO.getAllUsers(),HttpStatus.OK);
			}else {
				return new ResponseEntity<List<UserWrapper>>(new ArrayList<>(),HttpStatus.UNAUTHORIZED);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<List<UserWrapper>>(new ArrayList<>(),HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@Override
	public ResponseEntity<String> update(Map<String, String> requestMap) {
		try {
			if(jwtFilter.isAdmin()) {
				Optional<User> optional = userDAO.findById(Integer.parseInt(requestMap.get("id")));
				if(!optional.isEmpty()) {
					userDAO.updateStatus(requestMap.get("status"),Integer.parseInt(requestMap.get("id")));
					sendMailToAllAdmin(requestMap.get("status"),optional.get().getEmail(),userDAO.getAllAdmin());
					
					return CafeUtils.getResponseEntity("user Details updated successfully", HttpStatus.OK);
				}else {
					CafeUtils.getResponseEntity("user doesn't exist", HttpStatus.OK);
				}
			}else {
				return CafeUtils.getResponseEntity(CafeConstants.UNAUTHERIZED_ACCESS, HttpStatus.UNAUTHORIZED);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return CafeUtils.getResponseEntity(CafeConstants.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	private void sendMailToAllAdmin(String status, String user, List<String> allAdmin) {
		allAdmin.remove(jwtFilter.getCurrentUser());
		if(status != null && status.equalsIgnoreCase("true")) {
			emailUtils.sendSimpleMessage(jwtFilter.getCurrentUser(), "Account Approved", "USER :- "+user+"\n is approved by \n ADMIN :- "+jwtFilter.getCurrentUser(),allAdmin);
		}else {
			emailUtils.sendSimpleMessage(jwtFilter.getCurrentUser(), "Account Disabled", "USER :- "+user+"\n is disabled by \n ADMIN :- "+jwtFilter.getCurrentUser(),allAdmin);
		}
	}

	@Override
	public ResponseEntity<String> checkToken() {
		
		return CafeUtils.getResponseEntity("true", HttpStatus.OK);
	}

	@Override
	public ResponseEntity<String> changePassword(Map<String, String> requestMap) {
		try {
			User userObj = userDAO.findByEmail(jwtFilter.getCurrentUser());
			if(!userObj.equals(null)) {
				if(userObj.getPassword().equals(requestMap.get("oldPassword"))) {
					userObj.setPassword(requestMap.get("newPassword"));
					userDAO.save(userObj);
					return CafeUtils.getResponseEntity("password updated successfully", HttpStatus.OK);
				}
				return CafeUtils.getResponseEntity("incorrect old password", HttpStatus.BAD_REQUEST);

			}
			return CafeUtils.getResponseEntity(CafeConstants.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR);
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		return CafeUtils.getResponseEntity(CafeConstants.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@Override
	public ResponseEntity<String> forgetPassword(Map<String, String> requestMap) {
		try {
			User user = userDAO.findByEmail(requestMap.get("email"));
			if(!Objects.isNull(user) && !Strings.isNullOrEmpty(user.getEmail()))
				emailUtils.forgotMail(user.getEmail(), "Credentials by Cafe Management System", user.getPassword());
			return CafeUtils.getResponseEntity("Check your mail for Credintials", HttpStatus.OK); 
	
		}catch(Exception e) {
			e.printStackTrace();
		}
		return CafeUtils.getResponseEntity(CafeConstants.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
}
