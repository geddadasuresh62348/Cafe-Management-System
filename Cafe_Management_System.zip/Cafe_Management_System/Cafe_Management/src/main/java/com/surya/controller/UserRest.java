package com.surya.controller;

import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;

import com.surya.wrapper.UserWrapper;

public interface UserRest {
	
	public ResponseEntity<String> signUp(@RequestBody(required = true) Map<String, String> requestMap);
	
	public ResponseEntity<String> login(@RequestBody(required = true) Map<String,String>requestMap);
	
	public ResponseEntity<List<UserWrapper>> getAllUsers();
	
	public ResponseEntity<String> update(@RequestBody(required = true) Map<String,String> requestMap);
	
	public ResponseEntity<String> checkToken();
	
	public ResponseEntity<String> changePassword(@RequestBody Map<String,String> requestMap);
	
	public ResponseEntity<String> forgotPassword(@RequestBody Map<String,String> requestMap);

}
