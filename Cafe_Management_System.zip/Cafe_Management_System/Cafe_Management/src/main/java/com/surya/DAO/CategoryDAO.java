package com.surya.DAO;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.surya.model.Category;

public interface CategoryDAO extends JpaRepository<Category, Integer> {
	
	List<Category> getAllCategory();
}
