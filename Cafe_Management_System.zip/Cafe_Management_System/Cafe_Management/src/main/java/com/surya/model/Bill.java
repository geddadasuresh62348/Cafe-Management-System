package com.surya.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@NamedQuery(name = "Bill.getAllBills",query = "select b from Bill b order by b.id desc")
@NamedQuery(name = "Bill.getBillByUserName",query = "select b from Bill b where b.createdBy = :username order by b.id desc")

@Data
@Entity
@DynamicUpdate
@DynamicInsert
@NoArgsConstructor
@AllArgsConstructor
@Table
public class Bill implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column
	private Integer id;
	
	@Column
	private String uuid;
	
	@Column
	private String name;
	
	@Column
	private String email;
	
	@Column
	private String contactNumber;
	
	@Column
	private String paymentMethod;
	
	@Column
	private Integer totalAmount;
	
	@Column(columnDefinition = "json")
	private String productDetails;
	
	@Column
	private String createdBy;
}
